package com.ubs.megdp.finance.calculators

import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.MetadataBuilder


import com.ubs.megdp.core.calculator.MegDPCalculator
import org.apache.log4j.Logger

/**
  * This is a tenant calculator code.
  *
  * Please have tenant calculator logic block in the implemented run method.
  *
  */
//REGISTERED AS com.ubs.megdp.finance.calculators.MikellFinanceCalcX
class MikellFinanceCalcX extends MegDPCalculator {

  private lazy val logger: Logger = Logger.getLogger(getClass.getName)

  @Override
  override def init(args: Array[String]) {
    // Calculator initialization
    logger.info("init() sample run of MikellFinanceCalcX")
  }

  @Override
  override def run(args: Array[String]): Unit = {
    logger.info("run() sample run of MikellFinanceCalcX")

    val inputDatasets = getInputDatasets() // Get input datasets this calculator has access to
    val outputDatasets = getOutputDatasets() // Get output datasets this calculator has access to
    logger.info("***********************BASEBALL START")
    logger.info("Input Datasets: " + inputDatasets)
    logger.info("Output Datasets: " + outputDatasets)

    val peopleDF  = getDataset("com.ubs.megdp.finance.curated.merival.PeopleF")
    val battingDF  = getDataset("com.ubs.megdp.finance.curated.merival.BattingF")
    peopleDF.show(10, false)
    battingDF.show(10, false)

    val interumDF = peopleDF.join(battingDF, Seq("PLAYERID"), "left").select(col("PLAYERID"), col("FULLNAME"), col("RBI") )
    val resultsDF = interumDF.withColumn("COMMENTS", lit(args.mkString(", ")) )
    resultsDF.show(10, false)

    saveData("com.ubs.megdp.finance.curated.megdp.MikellBaseballResultsF", resultsDF)

    resultsDF.show(40, false)

  }


  // Because Datasets doing unions need the same number of columns [ which is rarely the case ]
  // this function will balance column elemants between the universe of columns from both datasets
  // Adding fake columns that never make it through the merge on union but passing the checks/balanaces
  // called two time, once for the left side, once for the right side
  def balanceColummns(myCols: Set[String], allCols: Set[String]) = {
    allCols.toList.map(x => x match {
      case x if myCols.contains(x) => col(x)
      case _ => lit(null).as(x)
    })
  }


  @Override
  override def terminate(args: Array[String]): Int = {
    // Calculator cleanup & terminate status
    // 0 - Success, 1 - Error
    logger.info("terminate() sample run of MikellFinanceCalcX")
    val returnCode = 0
    returnCode
  }
}
