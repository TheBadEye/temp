package com.ubs.megdp.ccar.entity.curated.megdp;

import com.ubs.megdp.core.annotation.MegDpColumn;

public class BaseballResultsCModel {

         //private String myControlSetSchema = "com.ubs.megdp.ccar.entity.curated.megdp.BaseballResultsCModel";
	 private String PLAYERID;
	 private String FULLNAME;
	 private String RBI;
	 private String COMMENTS;
	 private String NAMELAST;

	 public String getPLAYERID()  { return PLAYERID; }
	 public String getFULLNAME()  { return FULLNAME; }
	 public String getRBI() { return RBI; }
	 public String getCOMMENTS() { return COMMENTS; }

	 public void setPLAYERID(String inVal)  { PLAYERID  = inVal; }
	 public void setFULLNAME(String inVal)  { FULLNAME  = inVal; }
	 public void setRBI(String inVal) { RBI = inVal; }
	 public void setCOMMENTS(String inVal) { COMMENTS = inVal; }

	 public String toString() {
		 return "BaseballResultsModel{" +
			 "PLAYERID=" + PLAYERID + ", " +
			 "FULLNAME="  + FULLNAME + ", " +
			 "RBI=" + RBI + ", " +
			 "COMMENTS=" + COMMENTS + "}" ;
	 }
}
