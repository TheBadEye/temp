package com.ubs.megdp.ccar.entity.curated.merival;

import com.ubs.megdp.ccar.entity.common.BaseballSalaryRating;

import com.ubs.megdp.core.annotation.MegDpColumn;

import java.util.StringTokenizer;

public class BaseballSalaryCModel {

	 //private String myControlSetSchema = "com.ubs.megdp.ccar.entity.curated.merival.BaseballSalaryCModel";

	 private String PLAYERID;
	 private String SALARY;
	 private String COMPLEX_TYPE;
	 private String EXAMPLE_OF_UNUSED_FIELD;//this should not draw an error form moniker

	 public String getPLAYERID()     { return PLAYERID; }
	 public String getSALARY()       { return SALARY; }
	 public String getCOMPLEX_TYPE() { return COMPLEX_TYPE; }
	 // deseiralize from StringType of Parquet
	 //public BaseballSalaryRating decode() { return BaseballSalaryRating.fromString(COMPLEX_TYPE); }
	 public String decodeCITY() { 
		 StringTokenizer sTok = new StringTokenizer(COMPLEX_TYPE, "|");
		 return sTok.nextToken();
	 }

	 public void setPLAYERID(String inVal)     { PLAYERID  = inVal; }
	 public void setSALARY(String inVal)       { SALARY = inVal; }
	 public void setCOMPLEX_TYPE(String inVal) { COMPLEX_TYPE = inVal; }
	 // seiralize to StringType of Parquet
	 //public void encode(BaseballSalaryRating inVal) { COMPLEX_TYPE = inVal.toString(); }

	 public String toString() {
		 return "BaseballSalaryModel{" +
			 "PLAYERID="                     + PLAYERID + ", " +
			 "SALARY="                       + SALARY   + ", " +
			 "COMPLEX_TYPE="                 + COMPLEX_TYPE + "}" ;
	 }
}
