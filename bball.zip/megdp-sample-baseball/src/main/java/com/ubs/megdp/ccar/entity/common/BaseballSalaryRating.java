package com.ubs.megdp.ccar.entity.common;

import com.ubs.megdp.core.annotation.MegDpColumn;

import org.apache.log4j.Logger;

import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.StringTokenizer;

public class BaseballSalaryRating {


	 static Logger logger = Logger.getLogger("BaseballSalaryRatting");
	 private final static String _delimiter = "|";
	 private final static String _columnName = "SALARY_EVAL";

	 private String CITY = "UNSET";
	 private String MBA_LEAGUE = "UNSET";
	 private String SALARY_EVAL = "UNSET";


	 private BaseballSalaryRating(final String inCITY, final String inMBA_LEAGUE, final String inSALARY_EVAL) { 
	 	CITY 		= inCITY;
	 	MBA_LEAGUE 	= inMBA_LEAGUE;
	 	SALARY_EVAL 	= inSALARY_EVAL;
		logger.info("BaseBallSalaryRating: " + CITY +"."+ MBA_LEAGUE +"."+ SALARY_EVAL );
	 }

	 public static BaseballSalaryRating fromString(final String inValue) { 
		StringTokenizer sTok = new StringTokenizer(inValue, _delimiter);
		if(sTok.countTokens()==3)
			return new BaseballSalaryRating(sTok.nextToken(), sTok.nextToken(), sTok.nextToken());
		else{
		 	logger.error("Error: BaseballSalaryRating Tokens failed for: [" + inValue + "]");
			return null;
		}
	 }

	 public String getCITY() { return CITY; }
	 public String getMBA_LEAGUE() { return MBA_LEAGUE; }
	 public String getSALARY_EVAL() { return SALARY_EVAL; }

	 public void setCITY(final String inValue) { CITY  = inValue; }
	 public void setMBA_LEAGUE(final String inValue) { MBA_LEAGUE = inValue; }
	 public void setSALARY_EVAL(final String inValue) { SALARY_EVAL = inValue; }

	 public String toString() {
		 return new String( CITY + _delimiter + MBA_LEAGUE + _delimiter + SALARY_EVAL ); 
	 }
}
