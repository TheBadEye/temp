package com.ubs.megdp.ccar.entity.curated.merival;

import com.ubs.megdp.core.annotation.MegDpColumn;


public class BaseballTeamsCModel {

	 //private String myControlSetSchema = "com.ubs.megdp.ccar.entity.curated.merival.BaseballTeamsCModel";

	 private String YEARID;
	 private String LGID;
	 private String TEAMID;
	 private String FRANCHID;
	 private String NAME;
	 private String PARK;

	 public String getYEARID() { return YEARID; }
	 public String getLGID() { return LGID; }
	 public String getTEAMID()  { return TEAMID; }
	 public String getFRANCHID() { return FRANCHID; }
	 public String getNAME() { return NAME; }
	 public String getPARK() { return PARK; }

	 public void setYEAR(String inVal) { YEARID = inVal; }
	 public void setLGID(String inVal)  { LGID  = inVal; }
	 public void setTEAMID(String inVal)  { TEAMID  = inVal; }
	 public void setFRANCHID(String inVal) { FRANCHID = inVal; }
	 public void setNAME(String inVal) { NAME = inVal; }
	 public void setPARK(String inVal) { PARK = inVal; }

	 public String toString() {
		 return "BaseballBattingModel{" +
			 "YEARID="                     + YEARID    + ", " +
			 "LGID="                       + LGID      + ", " +
			 "TEAMID="                     + TEAMID    + ", " +
			 "FRANCHID="                   + FRANCHID  + ", " +
			 "NAME="                       + NAME      + ", " +
			 "PARK="                       + PARK      + "}" ;
	 }
}
