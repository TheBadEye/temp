package com.ubs.megdp.ccar.calculators;

import java.util.ArrayList;
import scala.collection.JavaConverters;

import org.apache.log4j.Logger;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.commons.lang3.StringUtils;

import com.ubs.megdp.core.exception.MegDPException;
import com.ubs.megdp.core.exception.MegDPMonikerException;
import com.ubs.megdp.core.java.calculator.MegDPCalculator;

// input ControlSets
import com.ubs.megdp.ccar.entity.curated.merival.BaseballPeopleCModel;
import com.ubs.megdp.ccar.entity.curated.merival.BaseballBattingCModel;
import com.ubs.megdp.ccar.entity.curated.merival.BaseballSalaryCModel;
import com.ubs.megdp.ccar.entity.curated.merival.BaseballTeamsCModel;
// output calc'ed ControlSets
import com.ubs.megdp.ccar.entity.curated.megdp.BaseballResultsCModel;
import com.ubs.megdp.ccar.entity.curated.megdp.BaseballSalaryEvalCModel;

import com.ubs.megdp.ccar.entity.common.BaseballSalaryRating;

import java.util.List;

/**
  * This is a tenant calculator code.
  *
  * Please have tenant calculator logic block in the implemented run method.
  *
  */
//REGISTERED AS com.ubs.megdp.ccar.calculators.MikellCCARJavaCalcX
public class MikellCCARJavaCalcX extends MegDPCalculator {

    private Logger logger = Logger.getLogger(this.getClass().getName());

    @Override
    public void init(String[] args) {
	        logger.info("init() sample run of MikellCCARJavaCalcX");

    }

    @Override
    public void run(String[] args) throws MegDPException {
	    try {

		logger.info("run(JAVA) sample run of MikellCCARJavaCalcX");

		Dataset<BaseballPeopleCModel>  peopleModel  = getData(BaseballPeopleCModel.class);
		Dataset<BaseballBattingCModel> battingModel = getData(BaseballBattingCModel.class);
		Dataset<BaseballSalaryCModel>  salaryModel  = getData(BaseballSalaryCModel.class);
		Dataset<BaseballTeamsCModel>   teamsModel   = getData(BaseballTeamsCModel.class);


		peopleModel.show(5, false);
		battingModel.show(5, false);
		teamsModel.show(5, false);
		salaryModel.show(5, false);

		ArrayList<String> joiner = new ArrayList<String>();
		joiner.add("PLAYERID");

		logger.info("*******JOINING people+batting DATA********");
		Dataset<Row> interumModel_1 = peopleModel.join(battingModel, scala.collection.JavaConverters.collectionAsScalaIterableConverter(joiner).asScala().toSeq(), "left");

		logger.info("*******JOINED people+batting DATA********");
		interumModel_1.printSchema();
	
		logger.info("*******SELECTING people+batting COLUMNS********");
		Dataset<Row> interumModel_2 = interumModel_1.select(interumModel_1.col("PLAYERID"), interumModel_1.col("FULLNAME"), interumModel_1.col("RBI") );

		logger.info("*******ADDING people+batting COMMENTS COLUMN********");
		Dataset<Row> resultsModel = interumModel_2.withColumn("COMMENTS", org.apache.spark.sql.functions.lit(org.apache.commons.lang3.StringUtils.join(args, ' ')) );


		resultsModel.show(10, false);

		logger.info("*******SAVING people+batting ResultSet********");
		// Moniker inside base MegDPCalculator asked to save result to registered output ControlSet
		saveData(BaseballResultsCModel.class, resultsModel);

		logger.info("*******JOINING people+salary DATA********");
		Dataset<Row> interumModel_3 = peopleModel.join(salaryModel, scala.collection.JavaConverters.collectionAsScalaIterableConverter(joiner).asScala().toSeq(), "left");

		logger.info("*******JOINED people+salary DATA********");
		interumModel_3.printSchema();

	
		logger.info("*******SELECTING people+salary COLUMNS********");
		Dataset<Row> interumModel_4 = interumModel_3.select(interumModel_3.col("PLAYERID"), interumModel_3.col("SALARY"), interumModel_3.col("COMPLEX_TYPE") );
		logger.info("*******Adding Column CITY people+salary********");

		Dataset<Row> interumModel_5 = interumModel_4.withColumn("CITY", interumModel_4.col("COMPLEX_TYPE") );
		interumModel_5.printSchema();
		logger.info("*******Adding Column MBA_LEAGUE people+salary********");
		Dataset<Row> interumModel_6 = interumModel_5.withColumn("MBA_LEAGUE", interumModel_4.col("COMPLEX_TYPE") );
		logger.info("*******Adding Column SALARY_EVAL people+salary********");
		Dataset<Row> interumModel_7 = interumModel_6.withColumn("SALARY_EVAL", interumModel_4.col("COMPLEX_TYPE") );
		logger.info("*******SAVING people+batting ResultSet********");

		interumModel_7.printSchema();
		interumModel_7.show(5, false);
		// Moniker inside base MegDPCalculator asked to save result to registered output ControlSet
		saveData(BaseballSalaryEvalCModel.class, interumModel_7);
    	} catch (Exception e) {
		logger.info("********MASTER EXCEPTION*********");
		e.printStackTrace();
		throw e;
    	}

    }

    @Override
    public int terminate(String[] args) {
	logger.info("terminate() sample run of MikellCCARJavaCalcX");
        return 0;
    }
}
