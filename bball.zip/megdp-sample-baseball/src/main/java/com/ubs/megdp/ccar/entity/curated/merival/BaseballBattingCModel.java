package com.ubs.megdp.ccar.entity.curated.merival;

import com.ubs.megdp.core.annotation.MegDpColumn;


public class BaseballBattingCModel {

	 //private String myControlSetSchema = "com.ubs.megdp.ccar.entity.curated.merival.BaseballBattingCModel";

	 private String PLAYERID;
	 private String YEARID;
	 private String RBI;
	 // Draws ... Error in Join operation, as duplicate column introduction: private String NAMELAST;
	 // Draws ... Error in Join operation, as duplicate column introduction: private String FULLNAME;
	 public String getPlayerID()  { return PLAYERID; }
	 public String getYearID() { return YEARID; }
	 public String getRBI() { return RBI; }
	 public void setPlayerID(String inVal)  { PLAYERID  = inVal; }
	 public void setYearID(String inVal) { YEARID = inVal; }
	 public void setRBI(String inVal) { RBI = inVal; }
	 public String toString() {
		 return "BaseballBattingModel{" +
			 "PLAYERID="                     + PLAYERID + ", " +
			 "YEARID="                       + YEARID   + ", " +
			 "RBI="                          + RBI      + "}" ;
	 }
}
