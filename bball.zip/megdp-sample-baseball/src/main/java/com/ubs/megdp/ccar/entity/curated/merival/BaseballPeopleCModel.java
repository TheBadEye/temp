package com.ubs.megdp.ccar.entity.curated.merival;

import com.ubs.megdp.core.annotation.MegDpColumn;

public class BaseballPeopleCModel {

	 //private String myControlSetSchema = "com.ubs.megdp.ccar.entity.curated.merival.BaseballPeopleCModel";

	 private String PLAYERID;
	 private String BIRTHYEAR;
	 private String NAMEFIRST;
	 private String NAMELAST;
	 private String FULLNAME;
	 public String getPlayerID()  { return PLAYERID; }
	 public String getBirthYear() { return BIRTHYEAR; }
	 public String getNameFirst() { return NAMEFIRST; }
	 public String getNameLast()  { return NAMELAST; }
	 public String getFullName()  { return FULLNAME; }
	 public void setPlayerID(String inVal)  { PLAYERID  = inVal; }
	 public void setBirthYear(String inVal) { BIRTHYEAR = inVal; }
	 public void setNameFirst(String inVal) { NAMEFIRST = inVal; }
	 public void setNameLast(String inVal)  { NAMELAST  = inVal; }
	 public void setFullName(String inVal)  { FULLNAME  = inVal; }
	 public String toString() {
		 return "BaseballPeopleModel{" +
			 "PLAYERID="  + PLAYERID  + ", " +
			 "BIRTHYEAR=" + BIRTHYEAR + ", " +
			 "NAMEFIRST=" + NAMEFIRST + ", " +
			 "NAMELAST="  + NAMELAST  + ", " +
			 "FULLNAME="  + FULLNAME  + "}";

	 }
}
