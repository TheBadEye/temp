package com.ubs.megdp.ccar.entity.curated.megdp;

import com.ubs.megdp.core.annotation.MegDpColumn;
import com.ubs.megdp.ccar.entity.common.BaseballSalaryRating;

public class BaseballSalaryEvalCModel {

         //private String myControlSetSchema = "com.ubs.megdp.ccar.entity.curated.megdp.BaseballSalaryEvalCModel";
	 private String PLAYERID;
	 private String CITY;
	 private String MBA_LEAGUE;
	 private BaseballSalaryRating SALARY_EVAL;
	 //private String SALARY_EVAL;

	 public String getPLAYERID()  { return PLAYERID; }
	 public String getCITY()  { return CITY; }
	 public String getMBA_LEAGUE() { return MBA_LEAGUE; }
	 public BaseballSalaryRating getSALARY_EVAL() { return SALARY_EVAL; }
	 //public String getSALARY_EVAL() { return SALARY_EVAL; }

	 public void setPLAYERID(String inVal)  { PLAYERID  = inVal; }
	 public void setCITY(String inVal)  { CITY  = inVal; }
	 public void setMBA_LEAGUE(String inVal) { MBA_LEAGUE = inVal; }
	 public void setSALARY_EVAL(BaseballSalaryRating inVal) { SALARY_EVAL = inVal; }
	 //public void setSALARY_EVAL(String inVal) { SALARY_EVAL = inVal; }

	 public String toString() {
		 return "BaseballSalaryEvalCModel{" +
			 "PLAYERID=" + PLAYERID + ", " +
			 "CITY="  + CITY + ", " +
			 "MBA_LEAGUE=" + MBA_LEAGUE + ", " +
			 "SALARY_EVAL=" + SALARY_EVAL + "}" ;
	 }
}
