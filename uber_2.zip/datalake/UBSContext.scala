package com.ubs.megdp.uberleben.datalake

import scala.collection.mutable.ListBuffer
import java.util.UUID.randomUUID


class UBSContext( val inName: String) extends Serializable {

  // Generating a fake id here
  var contextID =  randomUUID().toString
  var contextName = inName 
  var actions = new ListBuffer[UBSContextEvent]()

  def createContextEvent(inEventName: String ) : UBSContextEvent = {
    new UBSContextEvent(this, inEventName)
  }

  def publishGraphEvent(inEvent: UBSContextEvent ) : Unit = {
    println("\n\n<<<<<<<<NEW EVENT>>>>>>>>")
    println(inEvent)
    println("^^^^^^^^NEW EVENT^^^^^^^^\n")
  }


  def showEvents() : Unit = {
    println("UBSContext: "+"\n\tCONTEXTID: "+contextID+"\n\tCONTEXTNAME: "+contextName)
    actions.foreach { println }
    println("============DONE==============")
  }

  override def toString = "UBSContext: "+"\n\tCONTEXTID: "+contextID+"\n\tCONTEXTNAME: "+contextName

}
