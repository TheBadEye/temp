package com.ubs.megdp.uberleben.spark.sets

import com.ubs.megdp.uberleben.datalake.UBSContext
import com.ubs.megdp.uberleben.datalake.UBSContextEvent
import java.io.{ByteArrayOutputStream, CharArrayWriter, DataOutputStream}

import scala.annotation._
import scala.annotation.Annotation
import scala.annotation.StaticAnnotation
import scala.collection.JavaConverters._
import scala.collection.mutable.ArrayBuffer
import scala.language.implicitConversions
import scala.util.control.NonFatal

import org.apache.commons.lang3.StringUtils

import org.apache.spark.TaskContext
import org.apache.spark.api.java.JavaRDD
import org.apache.spark.api.java.function._
import org.apache.spark.api.python.{PythonRDD, SerDeUtil}
import org.apache.spark.api.r.RRDD
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.DataFrameStatFunctions
import org.apache.spark.sql.DataFrameNaFunctions
import org.apache.spark.sql.DataFrameWriter
import org.apache.spark.sql.Column
import org.apache.spark.sql.TypedColumn
import org.apache.spark.sql.RelationalGroupedDataset
import org.apache.spark.sql.KeyValueGroupedDataset
import org.apache.spark.sql.catalyst.analysis._
import org.apache.spark.sql.catalyst.catalog.HiveTableRelation
import org.apache.spark.sql.catalyst.encoders._
import org.apache.spark.sql.catalyst.expressions._
import org.apache.spark.sql.catalyst.expressions.codegen.GenerateSafeProjection
import org.apache.spark.sql.catalyst.json.{JacksonGenerator, JSONOptions}
import org.apache.spark.sql.catalyst.optimizer.CombineUnions
import org.apache.spark.sql.catalyst.parser.{ParseException, ParserUtils}
import org.apache.spark.sql.catalyst.plans._
import org.apache.spark.sql.catalyst.plans.logical._
import org.apache.spark.sql.catalyst.plans.physical.{Partitioning, PartitioningCollection}
import org.apache.spark.sql.execution._
import org.apache.spark.sql.execution.arrow.{ArrowBatchStreamWriter, ArrowConverters}
import org.apache.spark.sql.execution.command._
import org.apache.spark.sql.execution.datasources.LogicalRelation
import org.apache.spark.sql.Encoder
import org.apache.spark.sql.execution.python.EvaluatePython
import org.apache.spark.sql.execution.stat.StatFunctions
import org.apache.spark.sql.streaming.DataStreamWriter
import org.apache.spark.sql.types._
import org.apache.spark.sql.util.SchemaUtils
import org.apache.spark.sql.AnalysisException
import org.apache.spark.storage.StorageLevel
import org.apache.spark.unsafe.array.ByteArrayMethods
import org.apache.spark.unsafe.types.CalendarInterval
import org.apache.spark.util.Utils
import org.apache.spark.sql.Row


class UBSDataFrame private[sets](inUBSContext: UBSContext, inDataFrame: DataFrame) extends UBSDataset(inUBSContext, inDataFrame) {
/*
 * Not needed for now
  def this(inUBSContext: UBSContext, inDataset: Dataset ) {
    this.myDataset =  inUBSContext
    myContext =  inDataset
  }
*/

  var myDataFrame  = inUBSContext
}
