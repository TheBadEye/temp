package com.ubs.megdp.uberleben.datalake

import java.util.UUID.randomUUID


class UBSContext( val inName: String) extends Serializable {

  // Generating a fake id here
  var contextID =  randomUUID().toString
  var contextName = inName 

  def createContextEvent(inEventName: String ) : UBSContextEvent = {
    new UBSContextEvent(this, inEventName)
  }

  def publishGraphEvent(inEvent: UBSContextEvent ) : Unit = {
    println(inEvent)
  }

  override def toString = "UBSContext: "+"\n\tCONTEXTID: "+contextID+"\n\tCONTEXTNAME: "+contextName

}
