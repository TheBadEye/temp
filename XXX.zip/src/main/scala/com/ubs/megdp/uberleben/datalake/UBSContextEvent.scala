package com.ubs.megdp.uberleben.datalake

import java.io._
import java.util.UUID.randomUUID

class UBSContextEvent( val inUBSContext: UBSContext, val inName: String) extends Serializable {

  val myContext = inUBSContext
  // Generating a fake id here
  var eventID = randomUUID().toString
  var eventName = inName.toLowerCase()
  var action = "unset"

  def addAction(inAction : String ) : Unit = {
    action = inAction.toLowerCase()
  }

  def publishGraphEvent(inEvent: UBSContextEvent ) : Unit = {
  }

  override def toString = "UBSContextEvent: "+"\n\tEVENTID: "+eventID+"\n\tEVENTNAME: "+eventName+"\n\tACTION: "+action

}
